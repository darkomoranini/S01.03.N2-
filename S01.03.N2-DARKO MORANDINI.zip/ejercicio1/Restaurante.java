package ejercicio1;
import java.util.*;

public class Restaurante {
    private String nom;
    private int puntuacio;

    public Restaurante(String nom, int puntuacio) {
        this.nom = nom;
        this.puntuacio = puntuacio;
    }

    public String getNom() {
        return nom;
    }

    public int getPuntuacio() {
        return puntuacio;
    }

    public static void main(String[] args) {
        Set<String> restaurantKeys = new HashSet<>();
        Set<Restaurante> restaurantes = new HashSet<>();

        Restaurante restaurante1 = new Restaurante("Restaurant A", 5);
        Restaurante restaurante2 = new Restaurante("Restaurant B", 4);
        Restaurante restaurante3 = new Restaurante("Restaurant A", 5); // Duplicado

        String key1 = restaurante1.getNom() + "-" + restaurante1.getPuntuacio();
        if (restaurantKeys.add(key1)) {
            restaurantes.add(restaurante1);
        }

        String key2 = restaurante2.getNom() + "-" + restaurante2.getPuntuacio();
        if (restaurantKeys.add(key2)) {
            restaurantes.add(restaurante2);
        }

        String key3 = restaurante3.getNom() + "-" + restaurante3.getPuntuacio();
        if (restaurantKeys.add(key3)) {
            restaurantes.add(restaurante3);
        }

        System.out.println("Número de restaurantes en el HashSet: " + restaurantes.size());
        for (Restaurante restaurante : restaurantes) {
            System.out.println(restaurante.getNom() + " - Puntuación: " + restaurante.getPuntuacio());
        }
    }
}
