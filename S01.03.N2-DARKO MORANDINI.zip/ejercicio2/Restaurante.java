package ejercicio2;
import java.util.*;

public class Restaurante implements Comparable <Restaurante> {
    private String nom;
    private int puntuacio;

    public Restaurante(String nom, int puntuacio) {
        this.nom = nom;
        this.puntuacio = puntuacio;
    }

    public String getNom() {
        return nom;
    }

    public int getPuntuacio() {
        return puntuacio;
    }

    @Override
    public int compareTo(Restaurante otroRestaurante) {
        int comparacion = Integer.compare(this.puntuacio, otroRestaurante.puntuacio);
        if (comparacion == 0) {
            comparacion = this.nom.compareTo(otroRestaurante.nom);
        }
        return comparacion;
    }

    public static void main(String[] args) {
        Set<Restaurante> restaurantes = new TreeSet<>();

        Restaurante restaurante1 = new Restaurante("Restaurant A", 5);
        Restaurante restaurante2 = new Restaurante("Restaurant B", 4);
        Restaurante restaurante3 = new Restaurante("Restaurant C", 3);
        Restaurante restaurante4 = new Restaurante("Restaurant D", 5);
        restaurantes.add(restaurante1);
        restaurantes.add(restaurante2);
        restaurantes.add(restaurante3);
        restaurantes.add(restaurante4);
       

        System.out.println("Número de restaurantes en el conjunto: " + restaurantes.size());
        for (Restaurante restaurant : restaurantes) {
            System.out.println(restaurant.getNom() + " - Puntuación: " + restaurant.getPuntuacio());
        }
    }
}
